// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xkeccak_lane1.h"

extern XKeccak_lane1_Config XKeccak_lane1_ConfigTable[];

XKeccak_lane1_Config *XKeccak_lane1_LookupConfig(u16 DeviceId) {
	XKeccak_lane1_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XKECCAK_LANE1_NUM_INSTANCES; Index++) {
		if (XKeccak_lane1_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XKeccak_lane1_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XKeccak_lane1_Initialize(XKeccak_lane1 *InstancePtr, u16 DeviceId) {
	XKeccak_lane1_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XKeccak_lane1_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XKeccak_lane1_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

