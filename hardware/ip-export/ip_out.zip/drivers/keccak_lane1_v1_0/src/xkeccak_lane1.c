// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xkeccak_lane1.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XKeccak_lane1_CfgInitialize(XKeccak_lane1 *InstancePtr, XKeccak_lane1_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XKeccak_lane1_Start(XKeccak_lane1 *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKeccak_lane1_ReadReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_AP_CTRL) & 0x80;
    XKeccak_lane1_WriteReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XKeccak_lane1_IsDone(XKeccak_lane1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKeccak_lane1_ReadReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XKeccak_lane1_IsIdle(XKeccak_lane1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKeccak_lane1_ReadReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XKeccak_lane1_IsReady(XKeccak_lane1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKeccak_lane1_ReadReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XKeccak_lane1_EnableAutoRestart(XKeccak_lane1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKeccak_lane1_WriteReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_AP_CTRL, 0x80);
}

void XKeccak_lane1_DisableAutoRestart(XKeccak_lane1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKeccak_lane1_WriteReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_AP_CTRL, 0);
}

void XKeccak_lane1_Set_nstates(XKeccak_lane1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKeccak_lane1_WriteReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_NSTATES_DATA, Data);
}

u32 XKeccak_lane1_Get_nstates(XKeccak_lane1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XKeccak_lane1_ReadReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_NSTATES_DATA);
    return Data;
}

void XKeccak_lane1_InterruptGlobalEnable(XKeccak_lane1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKeccak_lane1_WriteReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_GIE, 1);
}

void XKeccak_lane1_InterruptGlobalDisable(XKeccak_lane1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKeccak_lane1_WriteReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_GIE, 0);
}

void XKeccak_lane1_InterruptEnable(XKeccak_lane1 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XKeccak_lane1_ReadReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_IER);
    XKeccak_lane1_WriteReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_IER, Register | Mask);
}

void XKeccak_lane1_InterruptDisable(XKeccak_lane1 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XKeccak_lane1_ReadReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_IER);
    XKeccak_lane1_WriteReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_IER, Register & (~Mask));
}

void XKeccak_lane1_InterruptClear(XKeccak_lane1 *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XKeccak_lane1_WriteReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_ISR, Mask);
}

u32 XKeccak_lane1_InterruptGetEnabled(XKeccak_lane1 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XKeccak_lane1_ReadReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_IER);
}

u32 XKeccak_lane1_InterruptGetStatus(XKeccak_lane1 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XKeccak_lane1_ReadReg(InstancePtr->Ctrl_BaseAddress, XKECCAK_LANE1_CTRL_ADDR_ISR);
}

